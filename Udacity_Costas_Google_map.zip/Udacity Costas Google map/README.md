#This is the Google Map project, created by Konstantinos Zeimpekis.

##Introduction
In this project you ll enjoy a map shows you some places to visit in New York City.

##Instructions
*Download the github repo: https://github.com/Aimpotis/map4
*Click map.html and let it open in your browser of your choice.
*Type the area you would like to visit in search bar at the left hand side
and click on it.
*Then an infowindow will pop up showing you the title of the marker and a NYT article.
*Click one of the item lists in the left side bar to get an animation of the marker and open the infowindow.

##Extra infos
The Google map is responsive to all devices, so you can enjoy it and from your smartphone.
